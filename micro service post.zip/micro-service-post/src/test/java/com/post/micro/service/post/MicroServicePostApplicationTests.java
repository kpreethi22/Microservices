package com.post.micro.service.post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicePostApplicationTests {

	@Test
	void contextLoads() {
	}

}
